﻿using System.Web.UI;

namespace Pickr.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}