﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pickr.Models
{
    public class Preferences
    {
        public bool Smoking { get; set; }
        public bool Music { get; set; }
        public bool Pets { get; set; }
        public int Talking { get; set; }
    }
}